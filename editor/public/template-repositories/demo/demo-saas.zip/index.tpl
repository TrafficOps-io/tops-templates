@template "Tandem SaaS" version=1 description="A clear, blue-and-white workspace launch with a project board, product features and a simple pricing section."

@section identity "Brand and action"
  @param brand String = "Tandem" label="Brand name" required
  @param headline String = "Good work happens together." label="Headline" required
  @param description Text = "A little structure. A lot more room to do your thing. Give your team one shared place for projects, decisions and the next step." label="Introduction"
  @param accent Color = "#265be7" label="Accent color"
  @param destination Url = "https://example.com" label="Sign-up URL"
  @param button String = "Start your workspace" label="Button label"
@endsection

@section product "Product and pricing"
  @param projectName String = "Website refresh" label="Demo project name"
  @param projectTarget String = "A new home for our next chapter" label="Demo project goal"
  @param workflowImage Image = "assets/workflow.svg" label="Workflow illustration"
  @param workflowImageAlt String = "Connected notes, task cards and a shared project folder" label="Workflow image description"
  @param featureHeadline String = "The plan and the people. In the same place." label="Feature heading"
  @param price String = "$12" label="Monthly price"
  @param priceNote String = "per person / month, billed monthly" label="Price details"
  @param offerNote Text = "A sample plan for growing teams. Replace this offer with your own pricing and terms before publishing." label="Offer details"
@endsection

@layout
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="A shared place for your team's projects, decisions and next steps.">
  <title>{{ brand }} — {{ headline }}</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body style="--accent: {{ accent }}">
  <a class="skip-link" href="#main">Skip to content</a>
  <header class="site-header" data-block="Navigation">
    <a class="wordmark" href="#home" aria-label="{{ brand }} home"><span class="brand-icon" aria-hidden="true"><i></i><i></i></span>{{ brand }}</a>
    <nav aria-label="Main navigation"><a href="#product">The workspace</a><a href="#pricing">Pricing</a></nav>
    <a class="header-cta" href="{{ destination }}">{{ button }}</a>
  </header>
  <main id="main">
    <section class="hero" id="home" data-block="Hero">
      <div class="hero-copy"><p class="hero-context"><span aria-hidden="true"></span>A shared workspace for small teams</p><h1>{{ headline }}</h1><p class="intro">{{ description }}</p><a class="button primary" href="{{ destination }}">{{ button }}<span aria-hidden="true">↗</span></a><a class="text-link" href="#product">Take a closer look</a></div>
      <div class="product-frame" aria-label="Illustrative project workspace">
        <div class="window-bar"><span class="window-dots" aria-hidden="true"><i></i><i></i><i></i></span><span>{{ brand }} / Team workspace</span><span class="demo-label">Product preview</span></div>
        <div class="workspace">
          <aside class="workspace-sidebar" aria-label="Example workspace navigation"><strong class="workspace-brand"><span class="workspace-avatar">T</span>Our team</strong><span class="sidebar-item">Overview</span><span class="sidebar-item active">Projects <b>4</b></span><span class="sidebar-item">Team notes</span><span class="sidebar-label">Your projects</span><span class="sidebar-project"><i aria-hidden="true"></i>{{ projectName }}</span><span class="sidebar-project"><i aria-hidden="true"></i>Product ideas</span><div class="sidebar-bottom"><span class="member-avatar">A</span><span>Alex Morgan<small>Team workspace</small></span></div></aside>
          <div class="project-area"><div class="project-heading"><div><p>Projects / In progress</p><h2>{{ projectName }}</h2><p class="project-target">{{ projectTarget }}</p></div><div class="avatar-group" aria-label="Three example team members"><span>AM</span><span>JL</span><span>SK</span></div></div>
            <div class="board-toolbar"><span class="selected-view">Board</span><span>List</span><span>Calendar</span><span class="project-scope">Design team</span></div>
            <div class="board">
              <div class="board-column"><h3><i class="status todo" aria-hidden="true"></i>To do <span>2</span></h3><article class="task"><span class="task-tag research">Research</span><h4>Find the right direction</h4><p>A few references to get us started.</p><div class="task-meta"><span>3 notes</span><span class="member-avatar peach">JL</span></div></article><article class="task"><span class="task-tag">Content</span><h4>Draft the story</h4><div class="task-meta"><span>Friday</span><span class="member-avatar">AM</span></div></article></div>
              <div class="board-column"><h3><i class="status progress" aria-hidden="true"></i>In progress <span>1</span></h3><article class="task featured-task"><span class="task-tag design">Design</span><div class="mini-layout" aria-hidden="true"><div><i></i><i></i><b></b></div><span></span></div><h4>Make a little room for ideas</h4><p>First concepts are ready for a look.</p><div class="task-meta"><span>2 of 4 tasks</span><span class="member-avatar lavender">SK</span></div></article></div>
              <div class="board-column"><h3><i class="status done" aria-hidden="true"></i>Done <span>1</span></h3><article class="task"><span class="task-tag planning">Planning</span><h4>Bring everyone together</h4><p>The brief is in. Let's make something good.</p><div class="task-meta"><span class="done-text">✓ Complete</span><span class="member-avatar">AM</span></div></article><p class="board-note">A clear next step.<br>A little less back and forth.</p></div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="principles container" id="product" data-block="Product benefits"><div class="section-heading"><h2>{{ featureHeadline }}</h2><p>Less hunting through tabs. More knowing where things stand.</p></div><div class="benefit-grid"><article><span class="feature-symbol" aria-hidden="true">▤</span><h3>Start with a clear plan</h3><p>Turn a loose idea into tasks with owners, dates and enough context to get moving.</p></article><article><span class="feature-symbol" aria-hidden="true">↔</span><h3>Keep the conversation close</h3><p>Leave feedback beside the work. Find the decision without retracing every conversation.</p></article><article><span class="feature-symbol" aria-hidden="true">✓</span><h3>See what needs you next</h3><p>A shared view of what is moving, what is waiting and what is ready to celebrate.</p></article></div></section>
    <section class="workflow container" data-block="Connected workflow"><div class="workflow-art"><img src="{{ workflowImage }}" alt="{{ workflowImageAlt }}" width="640" height="480" loading="lazy"></div><div class="workflow-copy"><p class="section-context">A calmer way to collaborate</p><h2>Make space for the work you love.</h2><p>You bring the idea. Your workspace keeps the moving pieces together, from the first rough note to the final handover.</p><ul><li>Tasks with a person and a purpose</li><li>Notes that live alongside your projects</li><li>A shared rhythm, wherever you work</li></ul><a class="text-link" href="{{ destination }}">{{ button }} <span aria-hidden="true">↗</span></a></div></section>
    <section class="pricing-section" id="pricing" data-block="Pricing"><div class="pricing container"><div><p class="section-context">Room for your whole team</p><h2>One workspace.<br>Everything in reach.</h2><p>{{ offerNote }}</p></div><article class="price-card"><h3>Team plan</h3><p class="price">{{ price }}</p><p class="price-note">{{ priceNote }}</p><ul><li>Shared projects and team notes</li><li>Board, list and calendar views</li><li>Guest access for collaborators</li></ul><a class="button primary" href="{{ destination }}">{{ button }} <span aria-hidden="true">↗</span></a></article></div></section>
  </main>
  <footer class="site-footer container" data-block="Footer"><a class="wordmark" href="#home"><span class="brand-icon" aria-hidden="true"><i></i><i></i></span>{{ brand }}</a><p>A little more together.</p><a href="#product">Explore the workspace</a></footer>
</body>
</html>
@endlayout
